#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
OUT="$(mktemp -d /tmp/autoskip-guard-check.XXXXXX)"
clang -std=c11 -Wall -Wextra -Werror -I. ASGPolicy.c tests/policy_test.c -o "$OUT/policy-test"
"$OUT/policy-test"
clang -fobjc-arc -fblocks -Wall -Wextra -Werror -I. -framework Foundation ASGMatchers.m tests/matchers_test.m -o "$OUT/matchers-test"
"$OUT/matchers-test"
clang -fobjc-arc -fblocks -Wall -Wextra -Werror -I. -framework Foundation ASGCache.m ASGPolicy.c tests/cache_test.m -o "$OUT/cache-test"
"$OUT/cache-test"
make all
codesign --verify --strict dist/AutoSkipGuard_0.2.0_arm64.dylib
otool -L dist/AutoSkipGuard_0.2.0_arm64.dylib
printf 'Check artifacts: %s\n' "$OUT"
