#import <UIKit/UIKit.h>

// App-local fallback. No global device events, no eager touch pool.
BOOL ASGPerformLocalTap(UIView *target, UIWindow *window, void (^completion)(BOOL));
