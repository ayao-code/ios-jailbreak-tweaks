#include "ASGPolicy.h"
#include <math.h>

bool ASGSessionValid(const ASGSession *s, uint64_t token, double now) {
    return s && s->active && s->generation == token && isfinite(now) && now < s->deadline;
}

bool ASGConsumeProbe(ASGSession *s, double now) {
    if (!s || !ASGSessionValid(s, s->generation, now) || s->verifying || s->probes >= 10) return false;
    s->probes++;
    return true;
}

bool ASGRectValid(double x, double y, double w, double h) {
    return isfinite(x) && isfinite(y) && isfinite(w) && isfinite(h)
        && x >= 0 && y >= 0 && w > 0 && h > 0 && x + w <= 1.001 && y + h <= 1.001;
}

bool ASGCornerButton(double x, double y, double w, double h) {
    if (!ASGRectValid(x, y, w, h)) return false;
    return w <= 0.40 && h <= 0.16 && y + h <= 0.30 && (x + w <= 0.40 || x >= 0.60);
}

bool ASGMayPromote(unsigned confirmations, bool verified, bool uncertain) {
    return confirmations >= 2 && verified && !uncertain;
}

bool ASGOCRResultValid(uint64_t current, uint64_t result, double age, bool samePage) {
    return current == result && isfinite(age) && age >= 0 && age <= 1.5 && samePage;
}

bool ASGOCRPairAgrees(double overlap, bool sameMeaning, bool samePage) {
    return isfinite(overlap) && overlap >= 0.65 && overlap <= 1 && sameMeaning && samePage;
}

bool ASGShouldAttemptSkip(bool visible, bool unique, bool skipSemantic, bool userInteraction, bool countdown, bool enabled) {
    (void)countdown;
    (void)enabled;
    // A valid skip is attempted even during countdown. A successful result is checked separately.
    return visible && unique && skipSemantic && userInteraction;
}

void ASGCancelSession(ASGSession *s) {
    if (!s) return;
    s->active = false;
    s->verifying = false;
    s->generation++;
}
