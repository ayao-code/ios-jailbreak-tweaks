#import <Foundation/Foundation.h>
BOOL ASGSkipText(NSString *text);
BOOL ASGSkipIdentifier(NSString *identifier);
BOOL ASGAdClass(NSString *name);
BOOL ASGCountdownText(NSString *text);
NSString *ASGSkipMeaning(NSString *text);
