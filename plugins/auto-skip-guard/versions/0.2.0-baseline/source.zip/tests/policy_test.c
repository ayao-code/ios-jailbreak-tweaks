#include "ASGPolicy.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

int main(void) {
    ASGSession session = {.generation = 4, .deadline = 4, .active = true};
    assert(ASGSessionValid(&session, 4, 0));
    assert(!ASGSessionValid(&session, 3, 0));
    assert(!ASGSessionValid(&session, 4, 4));
    assert(!ASGSessionValid(&session, 4, NAN));
    for (unsigned i = 0; i < 10; i++) assert(ASGConsumeProbe(&session, 1));
    assert(!ASGConsumeProbe(&session, 1));
    ASGCancelSession(&session);
    assert(!ASGSessionValid(&session, 4, 1));
    assert(session.generation == 5 && !session.active);
    assert(ASGCornerButton(.75, .05, .15, .05));
    assert(ASGCornerButton(.05, .05, .15, .05));
    assert(!ASGCornerButton(.45, .05, .15, .05));
    assert(!ASGCornerButton(.75, .75, .15, .05));
    assert(!ASGRectValid(NAN, 0, .1, .1));
    assert(!ASGRectValid(-.1, 0, .1, .1));
    assert(!ASGRectValid(0, 0, 0, .1));
    assert(!ASGRectValid(.9, 0, .2, .1));
    assert(!ASGMayPromote(1, true, false));
    assert(!ASGMayPromote(2, false, false));
    assert(!ASGMayPromote(2, true, true));
    assert(ASGMayPromote(2, true, false));
    assert(ASGOCRResultValid(5, 5, 1, true));
    assert(!ASGOCRResultValid(5, 4, 1, true));
    assert(!ASGOCRResultValid(5, 5, 2, true));
    assert(!ASGOCRResultValid(5, 5, 1, false));
    assert(!ASGOCRResultValid(5, 5, NAN, true));
    assert(ASGOCRPairAgrees(.8, true, true));
    assert(!ASGOCRPairAgrees(.8, false, true));
    assert(!ASGOCRPairAgrees(.3, true, true));
    assert(!ASGOCRPairAgrees(.8, true, false));
    assert(ASGShouldAttemptSkip(true, true, true, true, true, false));
    assert(ASGShouldAttemptSkip(true, true, true, true, false, true));
    assert(!ASGShouldAttemptSkip(true, true, false, true, true, false));
    assert(!ASGShouldAttemptSkip(true, false, true, true, true, true));
    assert(!ASGShouldAttemptSkip(false, true, true, true, true, true));
    assert(!ASGShouldAttemptSkip(true, true, true, false, true, true));
    puts("PASS policy: generation, deadlines, bounded probes, rectangles, uncertain promotion, stale OCR, changed-page/changed-position rejection");
    return 0;
}
