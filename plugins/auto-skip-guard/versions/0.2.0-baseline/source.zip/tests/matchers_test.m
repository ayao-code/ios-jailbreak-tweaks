#import <Foundation/Foundation.h>
#import "ASGMatchers.h"
#include <assert.h>

int main(void) {
    @autoreleasepool {
        for (NSString *s in @[@"跳过", @" Skip ", @"跳过 3s", @"跳过(5秒)", @"SKIP 2", @"5s 跳过", @"跳过广告 3秒", @"3 | 跳过", @"Skip ad (4)", @"跳过(0)"]) assert(ASGSkipText(s));
        for (NSString *s in @[@"关闭", @">>", @"点击跳过登录", @"跳过教程", @"skip login", @"", @"跳过 100秒"]) assert(!ASGSkipText(s));
        assert(!ASGSkipText(nil));
        assert(ASGSkipIdentifier(@"sdk_skip_button"));
        assert(!ASGSkipIdentifier(@"skipper_profile"));
        assert(ASGAdClass(@"BUSplashAdView"));
        assert(ASGAdClass(@"GADAppOpenAdController"));
        assert(!ASGAdClass(@"LoadingSplashView"));
        assert(!ASGAdClass(@"LoginViewController"));
        assert(!ASGAdClass(nil));
        assert(ASGCountdownText(@"跳过 3s"));
        assert(ASGCountdownText(@"5秒 跳过"));
        assert(!ASGCountdownText(@"跳过教程3"));
        assert([ASGSkipMeaning(@"跳过 3s") isEqual:ASGSkipMeaning(@"跳过 2s")]);
        assert(ASGSkipMeaning(@"关闭页面") == nil);
        puts("PASS matchers: countdown-prefix/suffix, ad-skip variants, changing-digit normalization, broad-close/login rejection");
    }
    return 0;
}
