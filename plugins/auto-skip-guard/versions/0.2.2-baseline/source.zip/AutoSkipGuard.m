#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import "ASGPolicy.h"
#import "ASGCache.h"
#import "ASGMatchers.h"
#import "ASGTouch.h"
#import "ASGDiagnostics.h"

static NSString *const ASGVersion = ASG_VERSION;
static BOOL ASGArmed;
static double ASGNow(void) { return CACurrentMediaTime(); }
static BOOL ASGHasWord(NSString *value, NSString *word) {
    return value.length && word.length && [value rangeOfString:word options:NSCaseInsensitiveSearch].location != NSNotFound;
}

static BOOL ASGExcludedPage(UIViewController *vc) {
    NSString *name = NSStringFromClass(vc.class).lowercaseString;
    for (NSString *word in @[@"login", @"signin", @"auth", @"permission", @"safari", @"browser", @"share", @"payment", @"purchase", @"onboard"]) {
        if (ASGHasWord(name, word)) return YES;
    }
    return NO;
}

static UIViewController *ASGTopController(UIViewController *root) {
    UIViewController *vc = root;
    for (NSUInteger i = 0; vc && i < 16; i++) {
        UIViewController *next = vc.presentedViewController;
        if (!next && [vc isKindOfClass:UINavigationController.class]) next = ((UINavigationController *)vc).visibleViewController;
        if (!next && [vc isKindOfClass:UITabBarController.class]) next = ((UITabBarController *)vc).selectedViewController;
        if (!next || next == vc) break;
        vc = next;
    }
    return vc;
}

static UIWindow *ASGWindow(void) {
    UIWindowScene *scene = nil;
    for (UIScene *candidate in UIApplication.sharedApplication.connectedScenes) {
        if (candidate.activationState != UISceneActivationStateForegroundActive || ![candidate isKindOfClass:UIWindowScene.class]) continue;
        if (scene) return nil; // Ambiguous scene: no action.
        scene = (UIWindowScene *)candidate;
    }
    UIWindow *best = nil;
    for (UIWindow *window in scene.windows) {
        if (window.hidden || window.alpha <= 0.01 || CGRectIsEmpty(window.bounds)) continue;
        NSString *name = NSStringFromClass(window.class);
        if (ASGHasWord(name, @"keyboard") || ASGHasWord(name, @"texteffects") ) continue;
        if (!best || window.windowLevel > best.windowLevel
            || (window.windowLevel == best.windowLevel && window.isKeyWindow)) best = window;
    }
    // Apps may use UIApplication's legacy windows even while Scene API is present.
    if (!best && !scene) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        for (UIWindow *window in UIApplication.sharedApplication.windows) {
            if (window.hidden || window.alpha <= 0.01 || CGRectIsEmpty(window.bounds)) continue;
            NSString *name = NSStringFromClass(window.class);
            if (ASGHasWord(name, @"keyboard") || ASGHasWord(name, @"texteffects")) continue;
            if (!best || window.windowLevel > best.windowLevel || (window.windowLevel == best.windowLevel && window.isKeyWindow)) best = window;
        }
#pragma clang diagnostic pop
    }
    return best;
}

static BOOL ASGVisible(UIView *view, UIWindow *window) {
    // UIWindow.window need not point to itself. Rejecting it prunes the entire search tree.
    if (!view || !window || (view != window && view.window != window) || CGRectIsEmpty(view.bounds)) return NO;
    UIView *ancestor = view;
    for (NSUInteger i = 0; ancestor && i < 32; i++, ancestor = ancestor.superview) {
        if (ancestor.hidden || ancestor.alpha <= 0.01) return NO;
    }
    CGRect rect = [view convertRect:view.bounds toView:window];
    return !CGRectIsNull(rect) && !CGRectIsInfinite(rect) && CGRectIntersectsRect(rect, window.bounds);
}

static CGRect ASGNormalizedRect(UIView *view, UIView *container) {
    CGRect rect = [view convertRect:view.bounds toView:container];
    CGRect bounds = container.bounds;
    if (bounds.size.width <= 0 || bounds.size.height <= 0) return CGRectNull;
    return CGRectMake((rect.origin.x - bounds.origin.x) / bounds.size.width,
                      (rect.origin.y - bounds.origin.y) / bounds.size.height,
                      rect.size.width / bounds.size.width, rect.size.height / bounds.size.height);
}

static BOOL ASGCorner(UIView *view, UIView *container) {
    CGRect r = ASGNormalizedRect(view, container);
    return ASGCornerButton(r.origin.x, r.origin.y, r.size.width, r.size.height);
}

static NSString *ASGText(UIView *view) {
    if ([view isKindOfClass:UILabel.class]) return ((UILabel *)view).text ?: ((UILabel *)view).attributedText.string;
    if ([view isKindOfClass:UIButton.class]) return [(UIButton *)view titleForState:UIControlStateNormal] ?: [(UIButton *)view attributedTitleForState:UIControlStateNormal].string;
    if ([view respondsToSelector:@selector(text)]) {
        @try {
            id text = ((id (*)(id, SEL))objc_msgSend)(view, @selector(text));
            if ([text isKindOfClass:NSString.class]) return text;
            if ([text isKindOfClass:NSAttributedString.class]) return [text string];
        } @catch (NSException *exception) { /* Fall through to accessibility. */ }
    }
    return view.accessibilityLabel;
}

static BOOL ASGControlSemantic(UIView *control) {
    if (ASGSkipText(ASGText(control)) || ASGSkipIdentifier(control.accessibilityIdentifier)) return YES;
    unsigned visited = 0;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:control.subviews];
    while (queue.count && visited++ < 12) {
        UIView *view = queue.lastObject;
        [queue removeLastObject];
        if (!view.hidden && view.alpha > 0.01 && ASGSkipText(ASGText(view))) return YES;
        if (queue.count + view.subviews.count < 16) [queue addObjectsFromArray:view.subviews];
    }
    return NO;
}

static UIView *ASGControlFromView(UIView *view, UIView *container) {
    for (unsigned i = 0; view && view != container && i < 5; i++, view = view.superview) {
        if ([view isKindOfClass:UIControl.class]) return view;
        for (UIGestureRecognizer *gesture in view.gestureRecognizers) {
            if ([gesture isKindOfClass:UITapGestureRecognizer.class] && gesture.enabled) return view;
        }
        if (view.isAccessibilityElement && (view.accessibilityTraits & UIAccessibilityTraitButton)) return view;
    }
    return nil;
}

static NSArray<NSNumber *> *ASGPath(UIView *control, UIView *container) {
    NSMutableArray *path = [NSMutableArray array];
    UIView *view = control;
    while (view && view != container && path.count < 16) {
        UIView *parent = view.superview;
        NSUInteger index = [parent.subviews indexOfObjectIdenticalTo:view];
        if (!parent || index == NSNotFound || index > 199) return nil;
        [path insertObject:@(index) atIndex:0];
        view = parent;
    }
    return view == container && path.count ? path : nil;
}

static UIView *ASGFollowPath(NSArray<NSNumber *> *path, UIView *container) {
    UIView *view = container;
    for (NSNumber *index in path) {
        if (index.unsignedIntegerValue >= view.subviews.count) return nil;
        view = view.subviews[index.unsignedIntegerValue];
    }
    return view;
}

static UIImage *ASGRenderROI(UIView *context, CGRect roi, BOOL *valid) {
    *valid = NO;
    if (!context || CGRectIsEmpty(roi) || CGRectIsInfinite(roi) || CGRectIsNull(roi)) return nil;
    CGFloat scale = MIN(2.0, MIN(512.0 / roi.size.width, 256.0 / roi.size.height));
    if (scale <= 0 || !isfinite(scale)) return nil;
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = scale;
    format.opaque = YES;
    format.preferredRange = UIGraphicsImageRendererFormatRangeStandard;
    double start = ASGNow();
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:roi.size format:format];
    __block BOOL drawn = NO;
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *r) {
        CGContextTranslateCTM(r.CGContext, -roi.origin.x, -roi.origin.y);
        drawn = [context drawViewHierarchyInRect:context.bounds afterScreenUpdates:NO];
    }];
    double duration = ASGNow() - start;
    ASGDiagnostic(@"roi_render", @{@"drawn": @(drawn), @"image": @(image.CGImage != NULL), @"durationMS": @(duration * 1000)});
    // Capture work cannot be preempted at 8ms; throwing away a usable 30ms image wastes
    // that work and disables the only fallback. Bound request count, not just frame time.
    *valid = drawn && image.CGImage;
    return image;
}

@interface ASGGuard : NSObject
+ (instancetype)shared;
- (void)activate;
- (void)cancel;
- (void)userTouched;
@end

@implementation ASGGuard {
    ASGSession _session;
    ASGCache *_cache;
    NSMutableArray *_observers;
    BOOL _ocrInFlight;
    BOOL _ocrStarted;
    BOOL _cacheMiss;
    BOOL _attempted;
    BOOL _extended;
    unsigned _attemptCount;
    unsigned _ocrPasses;
    CGRect _priorOCRRect;
    __weak UIViewController *_cycleController;
    BOOL _dispatchingSynthetic;
    BOOL _ocrDisabledForLaunch;
    BOOL _ocrPairPending;
    BOOL _sawCandidate;
    __weak UIView *_discoveredTarget;
    __weak UIView *_discoveredSource;
    id _ocrRequest;
    __weak UIWindow *_cycleWindow;
    __weak UIView *_waitingControl;
    __weak UIView *_waitingContainer;
    NSString *_bundle;
}

+ (instancetype)shared {
    static ASGGuard *guard;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ guard = [ASGGuard new]; });
    return guard;
}

- (instancetype)init {
    if ((self = [super init])) {
        _bundle = NSBundle.mainBundle.bundleIdentifier;
        NSURL *directory = [NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
        _cache = [[ASGCache alloc] initWithFileURL:[[directory URLByAppendingPathComponent:@"ayao.AutoSkipGuard" isDirectory:YES] URLByAppendingPathComponent:@"locators.plist"]];
        [_cache load];
        _observers = [NSMutableArray array];
        __weak ASGGuard *owner = self;
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        for (NSString *name in @[UIApplicationDidBecomeActiveNotification, UISceneDidActivateNotification]) {
            [_observers addObject:[center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) { [owner activate]; }]];
        }
        for (NSString *name in @[UIApplicationWillResignActiveNotification, UISceneWillDeactivateNotification,
                                 UISceneDidDisconnectNotification, UIApplicationDidReceiveMemoryWarningNotification]) {
            [_observers addObject:[center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                ASGGuard *guard = owner;
                if (!guard) return;
                if ([note.name isEqual:UIApplicationDidReceiveMemoryWarningNotification]) guard->_ocrDisabledForLaunch = YES;
                [guard cancel];
            }]];
        }
    }
    return self;
}

- (void)cancel {
    NSAssert(NSThread.isMainThread, @"UI ownership must be main-thread");
    ASGDiagnostic(@"cancel", @{@"probes": @(_session.probes), @"ocrPasses": @(_ocrPasses), @"actions": @(_attemptCount)});
    ASGCancelSession(&_session);
    ASGFlushDiagnostics();
    ASGArmed = NO;
    if ([_ocrRequest respondsToSelector:@selector(cancel)]) [_ocrRequest performSelector:@selector(cancel)];
    _ocrRequest = nil;
    _waitingControl = nil;
    _waitingContainer = nil;
    _cycleWindow = nil;
    _cycleController = nil;
    _discoveredTarget = nil;
    _discoveredSource = nil;
    // Keep inFlight set until the worker actually finishes. Cancellation does not dequeue work.
}

- (void)userTouched { if (_session.active && !_dispatchingSynthetic) [self cancel]; }

- (void)schedule:(NSTimeInterval)delay token:(uint64_t)token block:(void (^)(ASGGuard *))block {
    __weak ASGGuard *owner = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ASGGuard *guard = owner;
        if (!guard || !ASGSessionValid(&guard->_session, token, ASGNow())) return;
        block(guard);
    });
}

- (void)scheduleExpiration:(uint64_t)token {
    __weak ASGGuard *owner = self;
    NSTimeInterval delay = MAX(0.05, _session.deadline - ASGNow() + 0.05);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ASGGuard *guard = owner;
        if (!guard || !guard->_session.active || guard->_session.generation != token) return;
        // Do not use SessionValid here: expiration must clean up even after a busy runloop delays this block.
        if (ASGNow() >= guard->_session.deadline) [guard cancel];
        else [guard scheduleExpiration:token]; // A finite countdown/verification extension changed the deadline.
    });
}

- (void)activate {
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) {
        ASGDiagnostic(@"activation_not_active", nil); return;
    }
    if (_session.active && ASGNow() < _session.deadline) return;
    if (_session.active) [self cancel];
    _session.generation++;
    _session.active = YES;
    ASGArmed = YES;
    _session.verifying = NO;
    _session.deadline = ASGNow() + 10.0;
    _session.probes = 0;
    _ocrStarted = _cacheMiss = _attempted = _extended = _ocrPairPending = NO;
    _attemptCount = _ocrPasses = 0;
    _priorOCRRect = CGRectNull;
    _sawCandidate = NO;
    _cycleWindow = ASGWindow();
    _cycleController = ASGTopController(_cycleWindow.rootViewController);
    ASGDiagnostic(@"activated", @{@"window": @(_cycleWindow != nil), @"controller": @(_cycleController != nil)});
    uint64_t token = _session.generation;
    [self scheduleExpiration:token];
    for (NSNumber *delay in @[@0.15, @0.45, @0.9, @1.6, @2.6, @4.0, @5.5, @7.0]) {
        [self schedule:delay.doubleValue token:token block:^(ASGGuard *guard) { [guard probe:token]; }];
    }
    [self schedule:9.9 token:token block:^(ASGGuard *guard) {
        if (!guard->_extended && !guard->_session.verifying) [guard cancel];
    }];
}

- (NSString *)environment:(UIWindow *)window {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    CGRect bounds = window.bounds;
    UIEdgeInsets safe = window.safeAreaInsets;
    return [NSString stringWithFormat:@"%@|%@|%@|%@|%ld|%.0fx%.0f|%ld|%.0f,%.0f,%.0f,%.0f|%@|%@",
            _bundle, info[@"CFBundleShortVersionString"] ?: @"", info[@"CFBundleVersion"] ?: @"", ASGVersion,
            (long)NSProcessInfo.processInfo.operatingSystemVersion.majorVersion, bounds.size.width, bounds.size.height,
            (long)window.windowScene.interfaceOrientation, safe.top, safe.left, safe.bottom, safe.right,
            NSLocale.preferredLanguages.firstObject ?: @"", window.traitCollection.preferredContentSizeCategory];
}

- (UIView *)context:(UIWindow *)window {
    if (!window) return nil;
    UIViewController *vc = ASGTopController(window.rootViewController);
    if (ASGExcludedPage(vc)) return nil;
    UIView *root = vc.isViewLoaded ? vc.view : nil;
    if (ASGAdClass(NSStringFromClass(vc.class)) && ASGVisible(root, window)) return root;
    // Visit at most 200 nodes; no full-screen accessibility search or persistent hook.
    NSMutableArray<UIView *> *stack = root ? [NSMutableArray arrayWithObject:root] : [NSMutableArray array];
    double start = ASGNow();
    unsigned visited = 0;
    while (stack.count && visited++ < 200 && ASGNow() - start < 0.002) {
        UIView *view = stack.lastObject;
        [stack removeLastObject];
        if (!ASGVisible(view, window)) continue;
        CGRect rect = [view convertRect:view.bounds toView:window];
        BOOL large = rect.size.width >= window.bounds.size.width * 0.75 && rect.size.height >= window.bounds.size.height * 0.5;
        if (large && ASGAdClass(NSStringFromClass(view.class))) return view;
        if (stack.count + view.subviews.count <= 200) [stack addObjectsFromArray:view.subviews];
    }
    return window; // Generic discovery still requires unique, small corner skip UI.
}

- (BOOL)validControl:(UIView *)target container:(UIView *)container window:(UIWindow *)window requireText:(BOOL)requireText {
    if (!target || !container || !window || !target.userInteractionEnabled || !ASGVisible(target, window)
        || !ASGVisible(container, window) || ![target isDescendantOfView:container] || !ASGCorner(target, container)) return NO;
    BOOL indirectSemantic = target == _discoveredTarget && _discoveredSource
        && [_discoveredSource isDescendantOfView:target] && ASGVisible(_discoveredSource, window)
        && ASGSkipText(ASGText(_discoveredSource));
    BOOL semantic = ASGControlSemantic(target) || indirectSemantic;
    if ([target isKindOfClass:UIControl.class] && !((UIControl *)target).enabled && !semantic) return NO;
    if (requireText && !ASGShouldAttemptSkip(YES, YES, semantic, target.userInteractionEnabled,
                                           ASGCountdownText(ASGText(target)), ![target isKindOfClass:UIControl.class] || ((UIControl *)target).enabled)) return NO;
    CGRect rect = [target convertRect:target.bounds toView:window];
    UIView *hit = [window hitTest:CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect)) withEvent:nil];
    if (hit != target && ![hit isDescendantOfView:target]) ASGDiagnostic(@"target_hit_test_failed", @{@"disabledControl": @([target isKindOfClass:UIControl.class] && !((UIControl *)target).enabled)});
    return hit == target || [hit isDescendantOfView:target];
}

- (UIView *)nativeControl:(UIView *)container window:(UIWindow *)window {
    _discoveredTarget = nil;
    _discoveredSource = nil;
    __weak UIView *matchingSource = nil;
    NSMutableArray<UIView *> *stack = [NSMutableArray arrayWithObject:container];
    NSMutableSet<UIView *> *matches = [NSMutableSet set];
    double start = ASGNow();
    unsigned visited = 0;
    BOOL truncated = NO;
    while (stack.count && visited++ < 200 && ASGNow() - start < 0.002) {
        UIView *view = stack.lastObject;
        [stack removeLastObject];
        if (!ASGVisible(view, window)) continue;
        UIView *control = ASGControlFromView(view, container);
        if (!control && ASGSkipText(ASGText(view)) && ASGCorner(view, container)) {
            CGRect r = [view convertRect:view.bounds toView:window];
            UIView *hit = [window hitTest:CGPointMake(CGRectGetMidX(r), CGRectGetMidY(r)) withEvent:nil];
            if (hit && ASGCorner(hit, container)) control = hit;
        }
        if (control && (ASGSkipText(ASGText(view)) || ASGControlSemantic(control))
            && ASGCorner(control, container)) {
            [matches addObject:control];
            if (ASGSkipText(ASGText(view))) matchingSource = view;
        }
        if (matches.count > 1) { ASGDiagnostic(@"native_ambiguous", @{@"visited": @(visited)}); return nil; }
        if (stack.count + view.subviews.count <= 200) [stack addObjectsFromArray:view.subviews];
        else truncated = YES;
    }
    if (stack.count || truncated) { ASGDiagnostic(@"native_budget", @{@"visited": @(visited), @"matches": @(matches.count)}); return nil; }
    if (matches.count != 1) { ASGDiagnostic(@"native_no_match", @{@"visited": @(visited)}); return nil; }
    _discoveredTarget = matches.anyObject;
    _discoveredSource = matchingSource;
    ASGDiagnostic(@"native_candidate", @{@"visited": @(visited), @"control": @([_discoveredTarget isKindOfClass:UIControl.class])});
    return _discoveredTarget;
}

- (void)waitFor:(UIView *)control container:(UIView *)container token:(uint64_t)token {
    _waitingControl = control;
    _waitingContainer = container;
    if (_extended) return;
    _extended = YES;
    _session.deadline = MAX(_session.deadline, ASGNow() + 4.0);
    for (NSNumber *delay in @[@0.35, @0.75, @1.4, @2.2, @3.0]) {
        [self schedule:delay.doubleValue token:token block:^(ASGGuard *guard) {
            UIWindow *window = guard->_cycleWindow;
            UIView *target = guard->_waitingControl;
            UIView *context = guard->_waitingContainer;
            if (ASGWindow() != window || [guard context:window] != context) { [guard cancel]; return; }
            if ([guard validControl:target container:context window:window requireText:YES]) {
                [guard tap:target container:context window:window environment:[guard environment:window] token:token ocr:NO];
            }
        }];
    }
    [self schedule:3.9 token:token block:^(ASGGuard *guard) { if (!guard->_session.verifying) [guard cancel]; }];
}

- (void)probe:(uint64_t)token {
    if (!ASGConsumeProbe(&_session, ASGNow()) || _attempted) return;
    UIWindow *window = ASGWindow();
    if (!window) { ASGDiagnostic(@"probe_no_window", nil); return; }
    if (_cycleWindow && _cycleWindow != window) {
        if (_sawCandidate || _session.verifying) { [self cancel]; return; }
        _priorOCRRect = CGRectNull; // A newly presented splash window is not an app restriction.
    }
    _cycleWindow = window;
    UIViewController *currentController = ASGTopController(window.rootViewController);
    if (_cycleController && currentController != _cycleController) {
        if (_sawCandidate || _session.verifying) { [self cancel]; return; }
        _priorOCRRect = CGRectNull;
    }
    _cycleController = currentController;
    UIView *container = [self context:window];
    if (!container) { ASGDiagnostic(@"probe_no_context", nil); return; }
    NSString *environment = [self environment:window];
    if (!_cacheMiss) {
        for (NSDictionary *record in [_cache recordsForEnvironment:environment]) {
            UIView *control = [record[@"contextClass"] isEqual:NSStringFromClass(container.class)] ? ASGFollowPath(record[@"path"], container) : nil;
            CGRect actual = ASGNormalizedRect(control, container);
            NSArray *saved = record[@"rect"];
            BOOL geometry = saved.count == 4 && fabs(actual.origin.x - [saved[0] doubleValue]) < 0.025
                && fabs(actual.origin.y - [saved[1] doubleValue]) < 0.025
                && fabs(actual.size.width - [saved[2] doubleValue]) < 0.025
                && fabs(actual.size.height - [saved[3] doubleValue]) < 0.025;
            BOOL identity = control && [record[@"controlClass"] isEqual:NSStringFromClass(control.class)]
                && [record[@"identifier"] isEqual:control.accessibilityIdentifier ?: @""] && geometry;
            if (identity && [self validControl:control container:container window:window requireText:YES]) {
                _sawCandidate = YES;
                [self tap:control container:container window:window environment:environment token:token ocr:NO]; return;
            }
            if (identity && ASGControlSemantic(control) && [control isKindOfClass:UIControl.class] && !((UIControl *)control).enabled) { [self waitFor:control container:container token:token]; return; }
            _cacheMiss = YES;
            [_cache invalidateEnvironment:environment]; // Do not keep a failed locator usable.
        }
    }
    UIView *control = [self nativeControl:container window:window];
    if (control) {
        ASGDiagnostic(@"candidate_ready_check", @{@"enabled": @(![control isKindOfClass:UIControl.class] || ((UIControl *)control).enabled), @"interaction": @(control.userInteractionEnabled)});
        _sawCandidate = YES;
        if ([self validControl:control container:container window:window requireText:YES]) {
            [self tap:control container:container window:window environment:environment token:token ocr:NO]; return;
        }
        [self waitFor:control container:container token:token]; return;
    }
    // Do not spend both OCR passes on an empty first frame before an ad can appear.
    if (_session.probes >= 3) [self recognize:container window:window environment:environment token:token];
}

- (NSDictionary *)recordFor:(UIView *)control container:(UIView *)container {
    NSArray *path = ASGPath(control, container);
    CGRect r = ASGNormalizedRect(control, container);
    NSString *identifier = control.accessibilityIdentifier ?: @"";
    if ([container isKindOfClass:UIWindow.class] || !ASGControlSemantic(control)) return nil; // Unknown context/indirect text cannot authorize persistent learning.
    if (!path || identifier.length > 160 || !ASGRectValid(r.origin.x, r.origin.y, r.size.width, r.size.height)) return nil;
    return @{@"contextClass": NSStringFromClass(container.class), @"controlClass": NSStringFromClass(control.class),
             @"identifier": identifier, @"semantic": @"skip", @"path": path,
             @"rect": @[@(r.origin.x), @(r.origin.y), @(r.size.width), @(r.size.height)]};
}

- (void)tap:(UIView *)target container:(UIView *)container window:(UIWindow *)window
  environment:(NSString *)environment token:(uint64_t)token ocr:(BOOL)ocr {
    if (_attempted || _attemptCount >= 2 || !ASGSessionValid(&_session, token, ASGNow()) || ASGWindow() != window
        || [self context:window] != container || ![self validControl:target container:container window:window requireText:!ocr]) return;
    UIViewController *top = ASGTopController(window.rootViewController);
    UIViewController *expected = (top.isViewLoaded && top.view == container && top.presentingViewController)
        ? top.presentingViewController : top;
    if (!expected || ASGExcludedPage(expected)) return;
    NSDictionary *record = ocr ? nil : [self recordFor:target container:container];
    _attempted = YES;
    ASGDiagnostic(@"action_attempt", @{@"ocr": @(ocr), @"control": @([target isKindOfClass:UIControl.class])});
    _attemptCount++;
    _session.verifying = YES;
    _session.deadline = MAX(_session.deadline, ASGNow() + 1.5);
    BOOL dispatched = NO;
    _dispatchingSynthetic = YES;
    if ([target isKindOfClass:UIControl.class]) {
        UIControl *control = (UIControl *)target;
        UIControlEvents event = (control.allControlEvents & UIControlEventTouchUpInside) ? UIControlEventTouchUpInside
            : ((control.allControlEvents & UIControlEventPrimaryActionTriggered) ? UIControlEventPrimaryActionTriggered : 0);
        // Countdown is not a veto: try the skip action without changing enabled state.
        // The app may reject it; confirmation/retry decides success, not the attempted action.
        if (event) { [control sendActionsForControlEvents:event]; dispatched = YES; }
    }
    if (!dispatched && target.isAccessibilityElement && (target.accessibilityTraits & UIAccessibilityTraitButton)) {
        dispatched = [target accessibilityActivate];
    }
    if (!dispatched) {
        __weak ASGGuard *owner = self;
        dispatched = ASGPerformLocalTap(target, window, ^(BOOL ended) {
            ASGGuard *guard = owner;
            if (!ended && guard && ASGSessionValid(&guard->_session, token, ASGNow())) {
                [guard->_cache invalidateEnvironment:environment]; [guard cancel];
            }
        });
    }
    _dispatchingSynthetic = NO;
    ASGDiagnostic(dispatched ? @"action_dispatched" : @"action_failed", nil);
    if (!dispatched) { _attempted = NO; _session.verifying = NO; return; }
    __weak UIView *oldTarget = target;
    __weak UIView *oldContainer = container;
    __weak UIWindow *oldWindow = window;
    __weak UIViewController *expectedController = expected;
    [self schedule:0.8 token:token block:^(ASGGuard *guard) {
        UIWindow *current = ASGWindow();
        UIViewController *vc = ASGTopController(current.rootViewController);
        UIView *prior = oldContainer;
        BOOL strongSuccess = current && current == oldWindow && vc && vc == expectedController
            && !ASGExcludedPage(vc) && (![prior window] || prior.hidden) && prior != oldWindow
            && [guard context:current] == current;
        if (strongSuccess) {
            ASGDiagnostic(@"verified_exit", @{@"cacheEligible": @(record != nil)});
            if (record) [guard->_cache confirmRecord:record environment:environment];
            [guard cancel]; return;
        }
        // A generic root-container result has no trustworthy success oracle. Never cache it.
        BOOL stillSame = current && current == oldWindow && vc == expectedController;
        BOOL stillSkip = ASGControlSemantic(oldTarget) && ASGVisible(oldTarget, current);
        [guard->_cache invalidateEnvironment:environment];
        if (stillSame && stillSkip && guard->_attemptCount < 2) {
            guard->_attempted = NO;
            guard->_session.verifying = NO;
            [guard schedule:0.5 token:token block:^(ASGGuard *g) { [g probe:token]; }];
        } else [guard cancel];
    }];
}

- (void)recognize:(UIView *)container window:(UIWindow *)window environment:(NSString *)environment token:(uint64_t)token {
    NSProcessInfo *process = NSProcessInfo.processInfo;
    if ((_ocrStarted && _ocrPasses >= 3) || _ocrInFlight || _ocrDisabledForLaunch || process.lowPowerModeEnabled
        || process.thermalState >= NSProcessInfoThermalStateSerious) {
        ASGDiagnostic(@"ocr_gate", @{@"passes": @(_ocrPasses), @"inFlight": @(_ocrInFlight), @"disabled": @(_ocrDisabledForLaunch), @"lowPower": @(process.lowPowerModeEnabled), @"thermal": @(process.thermalState)}); return;
    }
    if (_ocrPasses >= 2 && !_ocrPairPending) return; // Reserve the third pass for confirmation, not repeated discovery.
    _ocrStarted = YES;
    _ocrPasses++;
    _ocrInFlight = YES; // Set before dispatch, not after completion.
    ASGDiagnostic(@"ocr_start", @{@"pass": @(_ocrPasses)});
    __weak ASGGuard *owner = self;
    __weak UIView *weakContainer = container;
    __weak UIWindow *weakWindow = window;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool {
            static void *vision;
            static dispatch_once_t once;
            dispatch_once(&once, ^{ vision = dlopen("/System/Library/Frameworks/Vision.framework/Vision", RTLD_LAZY | RTLD_LOCAL); });
            Class requestClass = vision ? NSClassFromString(@"VNRecognizeTextRequest") : Nil;
            Class handlerClass = vision ? NSClassFromString(@"VNImageRequestHandler") : Nil;
            dispatch_async(dispatch_get_main_queue(), ^{
                ASGGuard *guard = owner;
                if (!guard) return;
                UIView *context = weakContainer;
                UIWindow *activeWindow = weakWindow;
                if (!context || !activeWindow || !requestClass || !handlerClass || !ASGSessionValid(&guard->_session, token, ASGNow())
                    || guard->_session.verifying || ASGWindow() != activeWindow || [guard context:activeWindow] != context) {
                    guard->_ocrInFlight = NO; return;
                }
                // Crop during rendering, not after making a full-screen screenshot.
                CGRect bounds = context.bounds;
                CGRect roi = CGRectMake(bounds.origin.x, bounds.origin.y, bounds.size.width, bounds.size.height * 0.30);
                BOOL rendered;
                UIImage *image = ASGRenderROI(context, roi, &rendered);
                double capturedAt = ASGNow();
                if (!rendered) {
                    ASGDiagnostic(@"ocr_render_failed_or_slow", nil);
                    guard->_ocrDisabledForLaunch = YES; guard->_ocrInFlight = NO; return;
                }
                id request = [requestClass new];
                [request setValue:@0 forKey:@"recognitionLevel"];
                [request setValue:@NO forKey:@"usesLanguageCorrection"];
                [request setValue:@YES forKey:@"preferBackgroundProcessing"];
                guard->_ocrRequest = request;
                CGRect contextFrame = [context convertRect:context.bounds toView:activeWindow];
                __weak UIViewController *capturedController = ASGTopController(activeWindow.rootViewController);
                dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                    @autoreleasepool {
                        NSError *languageError = nil;
                        NSArray *languages = ((id (*)(id, SEL, NSError **))objc_msgSend)(request, NSSelectorFromString(@"supportedRecognitionLanguagesAndReturnError:"), &languageError);
                        NSMutableArray *chosen = [NSMutableArray array];
                        for (NSString *desired in @[@"zh-Hans", @"en-US"]) if ([languages containsObject:desired]) [chosen addObject:desired];
                        if (chosen.count) [request setValue:chosen forKey:@"recognitionLanguages"];
                        id handler = ((id (*)(id, SEL, CGImageRef, NSDictionary *))objc_msgSend)([handlerClass alloc], NSSelectorFromString(@"initWithCGImage:options:"), image.CGImage, @{});
                        NSError *error = nil;
                        BOOL ok = ((BOOL (*)(id, SEL, NSArray *, NSError **))objc_msgSend)(handler, NSSelectorFromString(@"performRequests:error:"), @[request], &error);
                        CGRect match = CGRectNull;
                        unsigned matches = 0;
                        if (ok && !error) {
                            for (id observation in [request valueForKey:@"results"]) {
                                NSArray *candidates = ((id (*)(id, SEL, NSUInteger))objc_msgSend)(observation, NSSelectorFromString(@"topCandidates:"), 1);
                                id candidate = candidates.firstObject;
                                if (!candidate || !ASGSkipText([candidate valueForKey:@"string"]) || [[candidate valueForKey:@"confidence"] floatValue] < 0.95) continue;
                                CGRect box = [[observation valueForKey:@"boundingBox"] CGRectValue];
                                if (!ASGRectValid(box.origin.x, box.origin.y, box.size.width, box.size.height)) continue;
                                match = CGRectMake(roi.origin.x + box.origin.x * roi.size.width,
                                                   roi.origin.y + (1 - box.origin.y - box.size.height) * roi.size.height,
                                                   box.size.width * roi.size.width, box.size.height * roi.size.height);
                                matches++;
                            }
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            ASGGuard *current = owner;
                            if (!current) return;
                            current->_ocrInFlight = NO;
                            ASGDiagnostic(@"ocr_results", @{@"matches": @(matches), @"ok": @(ok), @"error": @(error.code), @"ageMS": @((ASGNow() - capturedAt) * 1000)});
                            if (current->_ocrRequest == request) current->_ocrRequest = nil;
                            UIView *containerNow = weakContainer;
                            UIWindow *windowNow = weakWindow;
                            if (!containerNow || !windowNow || matches != 1 || !ASGSessionValid(&current->_session, token, ASGNow()) || current->_session.verifying
                                || ASGWindow() != windowNow || [current context:windowNow] != containerNow
                                || !ASGOCRResultValid(current->_session.generation, token, ASGNow() - capturedAt, ASGTopController(windowNow.rootViewController) == capturedController)
                                || !CGRectEqualToRect(contextFrame, [containerNow convertRect:containerNow.bounds toView:windowNow])) return;
                            if (CGRectIsNull(current->_priorOCRRect)) {
                                current->_priorOCRRect = match;
                                current->_sawCandidate = YES;
                                current->_ocrPairPending = YES;
                                [current recognize:containerNow window:windowNow environment:environment token:token];
                                return;
                            }
                            CGRect intersection = CGRectIntersection(match, current->_priorOCRRect);
                            double area = match.size.width * match.size.height;
                            double oldArea = current->_priorOCRRect.size.width * current->_priorOCRRect.size.height;
                            double shared = CGRectIsNull(intersection) ? 0 : intersection.size.width * intersection.size.height;
                            double overlap = area + oldArea > shared ? shared / (area + oldArea - shared) : 0;
                            if (!ASGOCRPairAgrees(overlap, true, true)) return;
                            current->_ocrPairPending = NO;
                            CGPoint point = [containerNow convertPoint:CGPointMake(CGRectGetMidX(match), CGRectGetMidY(match)) toView:windowNow];
                            UIView *hit = [windowNow hitTest:point withEvent:nil];
                            UIView *control = ASGControlFromView(hit, containerNow);
                            if (!control && ASGCorner(hit, containerNow)) control = hit;
                            // OCR does not license a blind coordinate tap or an uncertain persistent cache.
                            if ([current validControl:control container:containerNow window:windowNow requireText:NO]) {
                                [current tap:control container:containerNow window:windowNow environment:environment token:token ocr:YES];
                            }
                        });
                    }
                });
            });
        }
    });
}
@end

static void (*ASGOriginalSendEvent)(id, SEL, UIEvent *);
static void ASGSendEvent(id app, SEL selector, UIEvent *event) {
    if (ASGArmed && event.type == UIEventTypeTouches) {
        for (UITouch *touch in event.allTouches) if (touch.phase == UITouchPhaseBegan) { [[ASGGuard shared] userTouched]; break; }
    }
    ASGOriginalSendEvent(app, selector, event);
}

__attribute__((constructor)) static void ASGBootstrap(void) {
    // Required app-local dylib entry point: no OCR, disk I/O, or eager touch objects here.
    dispatch_async(dispatch_get_main_queue(), ^{
        ASGDiagnostic(@"bootstrap", nil);
        ASGGuard *guard = [ASGGuard shared];
        Method method = class_getInstanceMethod(UIApplication.class, @selector(sendEvent:));
        if (method) ASGOriginalSendEvent = (void (*)(id, SEL, UIEvent *))method_setImplementation(method, (IMP)ASGSendEvent);
        [guard activate];
#if ASG_DIAGNOSTICS
        // Flush also when no activation notification arrived; one debug-only write.
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 15 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            ASGFlushDiagnostics();
        });
#endif
    });
}
