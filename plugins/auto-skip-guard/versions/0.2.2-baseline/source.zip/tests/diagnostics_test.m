#import <Foundation/Foundation.h>
#import "ASGDiagnostics.h"
#include <assert.h>

int main(void) {
    @autoreleasepool {
        NSString *stage = NSUUID.UUID.UUIDString;
        NSURL *cache = [NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
        NSURL *url = [[cache URLByAppendingPathComponent:@"ayao.AutoSkipGuard"] URLByAppendingPathComponent:@"diagnostics.json"];
        for (unsigned i = 0; i < 80; i++) ASGDiagnostic(stage, @{@"index": @(i)});
        ASGFlushDiagnostics();
        ASGDiagnostic(@"after_flush_must_be_ignored", @{@"index": @100});
        ASGFlushDiagnostics();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            NSData *data = [NSData dataWithContentsOfURL:url];
            NSDictionary *plist = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSArray *events = plist[@"events"];
            assert(events.count == 64 && data.length <= 16384);
            assert([events.firstObject[@"stage"] isEqual:stage]);
            assert([events.lastObject[@"values"][@"index"] intValue] == 63);
            puts("PASS diagnostic bound: 64 numeric events, one write, post-flush events ignored");
            exit(0);
        });
    }
    for (;;) {
        @autoreleasepool { [NSRunLoop.mainRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.1]]; }
    }
}
