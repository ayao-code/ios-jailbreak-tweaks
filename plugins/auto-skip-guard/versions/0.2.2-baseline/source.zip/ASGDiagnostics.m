#import "ASGDiagnostics.h"
#import <QuartzCore/QuartzCore.h>

#if ASG_DIAGNOSTICS
static NSMutableArray<NSDictionary *> *ASGEvents;
static BOOL ASGFlushed;
#endif

void ASGRecordDiagnostic(NSString *stage, NSDictionary<NSString *, NSNumber *> *values) {
#if ASG_DIAGNOSTICS
    if (!NSThread.isMainThread || ASGFlushed) return;
    if (!ASGEvents) ASGEvents = [NSMutableArray arrayWithCapacity:64];
    if (ASGEvents.count >= 64) return;
    // Only fixed stages, numeric metadata. Never store UI text, class names or accounts.
    [ASGEvents addObject:@{@"stage": stage, @"uptime": @(CACurrentMediaTime()), @"values": values ?: @{}}];
#else
    (void)stage; (void)values;
#endif
}

void ASGFlushDiagnostics(void) {
#if ASG_DIAGNOSTICS
    if (!NSThread.isMainThread || ASGFlushed || !ASGEvents.count) return;
    ASGFlushed = YES;
    NSArray *snapshot = [ASGEvents copy];
    ASGEvents = nil;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool {
            NSData *data = [NSJSONSerialization dataWithJSONObject:@{@"schema": @1, @"events": snapshot}
                                                         options:0 error:NULL];
            if (!data || data.length > 16384) return;
            NSURL *cache = [NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
            NSURL *directory = [cache URLByAppendingPathComponent:@"ayao.AutoSkipGuard" isDirectory:YES];
            [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:NULL];
            NSDataWritingOptions options = NSDataWritingAtomic;
#if TARGET_OS_IPHONE
            options |= NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication;
#endif
            [data writeToURL:[directory URLByAppendingPathComponent:@"diagnostics.json"] options:options error:NULL];
        }
    });
#endif
}
