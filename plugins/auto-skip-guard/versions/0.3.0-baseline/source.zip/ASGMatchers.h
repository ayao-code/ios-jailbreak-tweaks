#import <Foundation/Foundation.h>
BOOL ASGSkipText(NSString *text);
BOOL ASGSkipIdentifier(NSString *identifier);
BOOL ASGAdClass(NSString *name);
BOOL ASGCountdownText(NSString *text);
NSString *ASGSkipMeaning(NSString *text);
typedef NS_ENUM(NSInteger, ASGActionKind) { ASGActionNone, ASGActionSkip, ASGActionCloseAd };
ASGActionKind ASGActionForText(NSString *text);
NSString *ASGMeaning(ASGActionKind kind);
