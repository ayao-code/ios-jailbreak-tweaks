#import <Foundation/Foundation.h>
#import "ASGDiagnostics.h"
#include <assert.h>

int main(void) {
    @autoreleasepool {
        NSString *stage = NSUUID.UUID.UUIDString;
        NSURL *cache = [NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
        NSURL *url = [[cache URLByAppendingPathComponent:@"ayao.AutoSkipGuard"] URLByAppendingPathComponent:@"diagnostics.json"];
        ASGStartDiagnosticCycle(10);
        for (unsigned i = 0; i < 80; i++) ASGDiagnostic(stage, @{@"index": @(i)});
        ASGFlushDiagnostics();
        ASGDiagnostic(@"after_flush_must_be_ignored", @{@"index": @100});
        ASGFlushDiagnostics();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            NSData *data = [NSData dataWithContentsOfURL:url];
            NSDictionary *plist = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
            NSArray *events = plist[@"events"];
            assert(events.count == 64 && data.length <= 16384);
            assert([events.firstObject[@"stage"] isEqual:stage]);
            assert([events.lastObject[@"values"][@"index"] intValue] == 63);
            ASGStartDiagnosticCycle(11);
            ASGDiagnostic(@"new_cycle", @{@"index": @1});
            ASGFlushDiagnostics();
            ASGStartDiagnosticCycle(12);
            ASGDiagnostic(@"cycle_12", @{@"index": @1});
            ASGFlushDiagnostics();
            ASGStartDiagnosticCycle(13);
            ASGDiagnostic(@"cycle_13", @{@"index": @1});
            ASGFlushDiagnostics();
            ASGStartDiagnosticCycle(14); // Hard four-cycle budget; keep last valid snapshot.
            ASGDiagnostic(@"must_not_write_cycle_14", @{@"index": @1});
            ASGFlushDiagnostics();
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                NSDictionary *current = [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfURL:url] options:0 error:NULL];
                assert([current[@"generation"] unsignedLongLongValue] == 13);
                assert([current[@"events"] count] == 1);
                assert([current[@"events"][0][@"stage"] isEqual:@"cycle_13"]);
                puts("PASS diagnostics: 64 events/cycle, finite 4-cycle budget, FIFO latest-generation readback");
                exit(0);
            });
        });
    }
    for (;;) {
        @autoreleasepool { [NSRunLoop.mainRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.1]]; }
    }
}
