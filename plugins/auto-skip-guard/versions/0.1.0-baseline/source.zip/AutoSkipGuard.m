#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <CommonCrypto/CommonDigest.h>
#import "ASGPolicy.h"
#import "ASGCache.h"
#import "ASGMatchers.h"

static NSString *const ASGVersion = @"0.1.0";
static BOOL ASGArmed;
static double ASGNow(void) { return CACurrentMediaTime(); }
static BOOL ASGHasWord(NSString *value, NSString *word) {
    return [value rangeOfString:word options:NSCaseInsensitiveSearch].location != NSNotFound;
}

static BOOL ASGExcludedPage(UIViewController *vc) {
    NSString *name = NSStringFromClass(vc.class).lowercaseString;
    for (NSString *word in @[@"login", @"signin", @"auth", @"permission", @"safari", @"browser", @"share", @"payment", @"purchase", @"onboard"]) {
        if (ASGHasWord(name, word)) return YES;
    }
    return NO;
}

static UIViewController *ASGTopController(UIViewController *root) {
    UIViewController *vc = root;
    for (NSUInteger i = 0; vc && i < 16; i++) {
        UIViewController *next = vc.presentedViewController;
        if (!next && [vc isKindOfClass:UINavigationController.class]) next = ((UINavigationController *)vc).visibleViewController;
        if (!next && [vc isKindOfClass:UITabBarController.class]) next = ((UITabBarController *)vc).selectedViewController;
        if (!next || next == vc) break;
        vc = next;
    }
    return vc;
}

static UIWindow *ASGWindow(void) {
    UIWindowScene *scene = nil;
    for (UIScene *candidate in UIApplication.sharedApplication.connectedScenes) {
        if (candidate.activationState != UISceneActivationStateForegroundActive || ![candidate isKindOfClass:UIWindowScene.class]) continue;
        if (scene) return nil; // Ambiguous scene: no action.
        scene = (UIWindowScene *)candidate;
    }
    UIWindow *best = nil;
    for (UIWindow *window in scene.windows) {
        if (window.hidden || window.alpha <= 0.01 || CGRectIsEmpty(window.bounds)) continue;
        NSString *name = NSStringFromClass(window.class);
        if (ASGHasWord(name, @"keyboard") || ASGHasWord(name, @"texteffects") || window.windowLevel >= UIWindowLevelAlert) return nil;
        if (!best || window.windowLevel > best.windowLevel
            || (window.windowLevel == best.windowLevel && window.isKeyWindow)) best = window;
    }
    return best;
}

static BOOL ASGVisible(UIView *view, UIWindow *window) {
    if (!view || !window || view.window != window || CGRectIsEmpty(view.bounds)) return NO;
    UIView *ancestor = view;
    for (NSUInteger i = 0; ancestor && i < 32; i++, ancestor = ancestor.superview) {
        if (ancestor.hidden || ancestor.alpha <= 0.01) return NO;
    }
    CGRect rect = [view convertRect:view.bounds toView:window];
    return !CGRectIsNull(rect) && !CGRectIsInfinite(rect) && CGRectIntersectsRect(rect, window.bounds);
}

static CGRect ASGNormalizedRect(UIView *view, UIView *container) {
    CGRect rect = [view convertRect:view.bounds toView:container];
    CGRect bounds = container.bounds;
    if (bounds.size.width <= 0 || bounds.size.height <= 0) return CGRectNull;
    return CGRectMake((rect.origin.x - bounds.origin.x) / bounds.size.width,
                      (rect.origin.y - bounds.origin.y) / bounds.size.height,
                      rect.size.width / bounds.size.width, rect.size.height / bounds.size.height);
}

static BOOL ASGCorner(UIView *view, UIView *container) {
    CGRect r = ASGNormalizedRect(view, container);
    return ASGCornerButton(r.origin.x, r.origin.y, r.size.width, r.size.height);
}

static NSString *ASGText(UIView *view) {
    if ([view isKindOfClass:UILabel.class]) return ((UILabel *)view).text ?: ((UILabel *)view).attributedText.string;
    if ([view isKindOfClass:UIButton.class]) return [(UIButton *)view titleForState:UIControlStateNormal] ?: [(UIButton *)view attributedTitleForState:UIControlStateNormal].string;
    return view.accessibilityLabel;
}

static BOOL ASGControlSemantic(UIControl *control) {
    if (ASGSkipText(ASGText(control)) || ASGSkipIdentifier(control.accessibilityIdentifier)) return YES;
    unsigned visited = 0;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:control.subviews];
    while (queue.count && visited++ < 12) {
        UIView *view = queue.lastObject;
        [queue removeLastObject];
        if (!view.hidden && view.alpha > 0.01 && ASGSkipText(ASGText(view))) return YES;
        if (queue.count + view.subviews.count < 16) [queue addObjectsFromArray:view.subviews];
    }
    return NO;
}

static UIControl *ASGControlFromView(UIView *view, UIView *container) {
    for (unsigned i = 0; view && view != container && i < 5; i++, view = view.superview) {
        if ([view isKindOfClass:UIControl.class]) return (UIControl *)view;
    }
    return nil;
}

static NSArray<NSNumber *> *ASGPath(UIControl *control, UIView *container) {
    NSMutableArray *path = [NSMutableArray array];
    UIView *view = control;
    while (view && view != container && path.count < 16) {
        UIView *parent = view.superview;
        NSUInteger index = [parent.subviews indexOfObjectIdenticalTo:view];
        if (!parent || index == NSNotFound || index > 199) return nil;
        [path insertObject:@(index) atIndex:0];
        view = parent;
    }
    return view == container && path.count ? path : nil;
}

static UIControl *ASGFollowPath(NSArray<NSNumber *> *path, UIView *container) {
    UIView *view = container;
    for (NSNumber *index in path) {
        if (index.unsignedIntegerValue >= view.subviews.count) return nil;
        view = view.subviews[index.unsignedIntegerValue];
    }
    return [view isKindOfClass:UIControl.class] ? (UIControl *)view : nil;
}

static UIImage *ASGRenderROI(UIView *context, CGRect roi, BOOL *valid) {
    *valid = NO;
    if (!context || CGRectIsEmpty(roi) || CGRectIsInfinite(roi) || CGRectIsNull(roi)) return nil;
    CGFloat scale = MIN(2.0, MIN(512.0 / roi.size.width, 256.0 / roi.size.height));
    if (scale <= 0 || !isfinite(scale)) return nil;
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = scale;
    format.opaque = YES;
    format.preferredRange = UIGraphicsImageRendererFormatRangeStandard;
    double start = ASGNow();
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:roi.size format:format];
    __block BOOL drawn = NO;
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *r) {
        CGContextTranslateCTM(r.CGContext, -roi.origin.x, -roi.origin.y);
        drawn = [context drawViewHierarchyInRect:context.bounds afterScreenUpdates:NO];
    }];
    *valid = drawn && image.CGImage && ASGNow() - start <= 0.008;
    return image;
}

static NSData *ASGImageDigest(UIImage *image) {
    if (!image.CGImage) return nil;
    CFDataRef pixels = CGDataProviderCopyData(CGImageGetDataProvider(image.CGImage));
    if (!pixels) return nil;
    unsigned char hash[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(CFDataGetBytePtr(pixels), (CC_LONG)CFDataGetLength(pixels), hash);
    CFRelease(pixels);
    return [NSData dataWithBytes:hash length:sizeof(hash)];
}

@interface ASGGuard : NSObject
+ (instancetype)shared;
- (void)activate;
- (void)cancel;
- (void)userTouched;
@end

@implementation ASGGuard {
    ASGSession _session;
    ASGCache *_cache;
    NSMutableArray *_observers;
    BOOL _ocrInFlight;
    BOOL _ocrStarted;
    BOOL _cacheMiss;
    BOOL _attempted;
    BOOL _extended;
    BOOL _ocrDisabledForLaunch;
    id _ocrRequest;
    __weak UIWindow *_cycleWindow;
    __weak UIControl *_waitingControl;
    __weak UIView *_waitingContainer;
    NSString *_bundle;
}

+ (instancetype)shared {
    static ASGGuard *guard;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ guard = [ASGGuard new]; });
    return guard;
}

- (instancetype)init {
    if ((self = [super init])) {
        _bundle = NSBundle.mainBundle.bundleIdentifier;
        NSURL *directory = [NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
        _cache = [[ASGCache alloc] initWithFileURL:[[directory URLByAppendingPathComponent:@"ayao.AutoSkipGuard" isDirectory:YES] URLByAppendingPathComponent:@"locators.plist"]];
        [_cache load];
        _observers = [NSMutableArray array];
        __weak ASGGuard *owner = self;
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        for (NSString *name in @[UIApplicationDidBecomeActiveNotification, UISceneDidActivateNotification]) {
            [_observers addObject:[center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) { [owner activate]; }]];
        }
        for (NSString *name in @[UIApplicationWillResignActiveNotification, UISceneWillDeactivateNotification,
                                 UISceneDidDisconnectNotification, UIApplicationDidReceiveMemoryWarningNotification]) {
            [_observers addObject:[center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                ASGGuard *guard = owner;
                if (!guard) return;
                if ([note.name isEqual:UIApplicationDidReceiveMemoryWarningNotification]) guard->_ocrDisabledForLaunch = YES;
                [guard cancel];
            }]];
        }
    }
    return self;
}

- (void)cancel {
    NSAssert(NSThread.isMainThread, @"UI ownership must be main-thread");
    ASGCancelSession(&_session);
    ASGArmed = NO;
    if ([_ocrRequest respondsToSelector:@selector(cancel)]) [_ocrRequest performSelector:@selector(cancel)];
    _ocrRequest = nil;
    _waitingControl = nil;
    _waitingContainer = nil;
    _cycleWindow = nil;
    // Keep inFlight set until the worker actually finishes. Cancellation does not dequeue work.
}

- (void)userTouched { if (_session.active) [self cancel]; }

- (void)schedule:(NSTimeInterval)delay token:(uint64_t)token block:(void (^)(ASGGuard *))block {
    __weak ASGGuard *owner = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ASGGuard *guard = owner;
        if (!guard || !ASGSessionValid(&guard->_session, token, ASGNow())) return;
        block(guard);
    });
}

- (void)activate {
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    if (_session.active && ASGNow() < _session.deadline) return;
    if (_session.active) [self cancel];
    _session.generation++;
    _session.active = YES;
    ASGArmed = YES;
    _session.verifying = NO;
    _session.deadline = ASGNow() + 4.0;
    _session.probes = 0;
    _ocrStarted = _cacheMiss = _attempted = _extended = NO;
    _cycleWindow = ASGWindow();
    uint64_t token = _session.generation;
    for (NSNumber *delay in @[@0.25, @0.8, @1.6, @3.2]) {
        [self schedule:delay.doubleValue token:token block:^(ASGGuard *guard) { [guard probe:token]; }];
    }
    [self schedule:3.95 token:token block:^(ASGGuard *guard) {
        if (!guard->_extended && !guard->_session.verifying) [guard cancel];
    }];
}

- (NSString *)environment:(UIWindow *)window {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    CGRect bounds = window.bounds;
    UIEdgeInsets safe = window.safeAreaInsets;
    return [NSString stringWithFormat:@"%@|%@|%@|%@|%ld|%.0fx%.0f|%ld|%.0f,%.0f,%.0f,%.0f|%@|%@",
            _bundle, info[@"CFBundleShortVersionString"] ?: @"", info[@"CFBundleVersion"] ?: @"", ASGVersion,
            (long)NSProcessInfo.processInfo.operatingSystemVersion.majorVersion, bounds.size.width, bounds.size.height,
            (long)window.windowScene.interfaceOrientation, safe.top, safe.left, safe.bottom, safe.right,
            NSLocale.preferredLanguages.firstObject ?: @"", window.traitCollection.preferredContentSizeCategory];
}

- (UIView *)context:(UIWindow *)window {
    if (!window) return nil;
    UIViewController *vc = ASGTopController(window.rootViewController);
    if (!vc || ASGExcludedPage(vc)) return nil;
    UIView *root = vc.isViewLoaded ? vc.view : nil;
    if (ASGAdClass(NSStringFromClass(vc.class)) && ASGVisible(root, window)) return root;
    // Visit at most 200 nodes; no full-screen accessibility search or persistent hook.
    NSMutableArray<UIView *> *stack = root ? [NSMutableArray arrayWithObject:root] : [NSMutableArray array];
    double start = ASGNow();
    unsigned visited = 0;
    while (stack.count && visited++ < 200 && ASGNow() - start < 0.002) {
        UIView *view = stack.lastObject;
        [stack removeLastObject];
        if (!ASGVisible(view, window)) continue;
        CGRect rect = [view convertRect:view.bounds toView:window];
        BOOL large = rect.size.width >= window.bounds.size.width * 0.75 && rect.size.height >= window.bounds.size.height * 0.5;
        if (large && ASGAdClass(NSStringFromClass(view.class))) return view;
        if (stack.count + view.subviews.count <= 200) [stack addObjectsFromArray:view.subviews];
    }
    return nil; // Unknown launch screen is not an advertisement oracle.
}

- (BOOL)validControl:(UIControl *)control container:(UIView *)container window:(UIWindow *)window requireText:(BOOL)requireText {
    if (!control || !container || !window || !control.enabled || !control.userInteractionEnabled || !ASGVisible(control, window)
        || !ASGVisible(container, window) || ![control isDescendantOfView:container] || !ASGCorner(control, container)) return NO;
    if (requireText && !ASGControlSemantic(control)) return NO;
    if (control.allTargets.count == 0 && !control.allControlEvents) return NO;
    CGRect rect = [control convertRect:control.bounds toView:window];
    UIView *hit = [window hitTest:CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect)) withEvent:nil];
    return hit == control || [hit isDescendantOfView:control];
}

- (UIControl *)nativeControl:(UIView *)container window:(UIWindow *)window {
    NSMutableArray<UIView *> *stack = [NSMutableArray arrayWithObject:container];
    NSMutableSet<UIControl *> *matches = [NSMutableSet set];
    double start = ASGNow();
    unsigned visited = 0;
    while (stack.count && visited++ < 200 && ASGNow() - start < 0.002) {
        UIView *view = stack.lastObject;
        [stack removeLastObject];
        if (!ASGVisible(view, window)) continue;
        UIControl *control = ASGControlFromView(view, container);
        if (control && (ASGSkipText(ASGText(view)) || ASGControlSemantic(control))
            && ASGCorner(control, container)) [matches addObject:control];
        if (matches.count > 1) return nil; // Ambiguity is not resolved by picking the topmost string.
        if (stack.count + view.subviews.count <= 200) [stack addObjectsFromArray:view.subviews];
    }
    if (stack.count) return nil; // Budget exhaustion could hide a second candidate.
    return matches.count == 1 ? matches.anyObject : nil;
}

- (void)waitFor:(UIControl *)control container:(UIView *)container token:(uint64_t)token {
    _waitingControl = control;
    _waitingContainer = container;
    if (_extended) return;
    _extended = YES;
    _session.deadline = ASGNow() + 4.0;
    for (NSNumber *delay in @[@0.6, @1.8, @3.0]) {
        [self schedule:delay.doubleValue token:token block:^(ASGGuard *guard) {
            UIWindow *window = guard->_cycleWindow;
            UIControl *target = guard->_waitingControl;
            UIView *context = guard->_waitingContainer;
            if (ASGWindow() != window || [guard context:window] != context) { [guard cancel]; return; }
            if ([guard validControl:target container:context window:window requireText:YES]) {
                [guard tap:target container:context window:window environment:[guard environment:window] token:token ocr:NO];
            }
        }];
    }
    [self schedule:3.9 token:token block:^(ASGGuard *guard) { if (!guard->_session.verifying) [guard cancel]; }];
}

- (void)probe:(uint64_t)token {
    if (!ASGConsumeProbe(&_session, ASGNow()) || _attempted) return;
    UIWindow *window = ASGWindow();
    if (!window) return;
    if (_cycleWindow && _cycleWindow != window) { [self cancel]; return; }
    _cycleWindow = window;
    UIView *container = [self context:window];
    if (!container) return;
    NSString *environment = [self environment:window];
    if (!_cacheMiss) {
        for (NSDictionary *record in [_cache recordsForEnvironment:environment]) {
            UIControl *control = [record[@"contextClass"] isEqual:NSStringFromClass(container.class)] ? ASGFollowPath(record[@"path"], container) : nil;
            BOOL identity = control && [record[@"controlClass"] isEqual:NSStringFromClass(control.class)]
                && [record[@"identifier"] isEqual:control.accessibilityIdentifier ?: @""];
            if (identity && [self validControl:control container:container window:window requireText:YES]) {
                [self tap:control container:container window:window environment:environment token:token ocr:NO]; return;
            }
            if (identity && ASGControlSemantic(control) && !control.enabled) { [self waitFor:control container:container token:token]; return; }
            _cacheMiss = YES;
            [_cache invalidateEnvironment:environment]; // Do not keep a failed locator usable.
        }
    }
    UIControl *control = [self nativeControl:container window:window];
    if (control) {
        if ([self validControl:control container:container window:window requireText:YES]) {
            [self tap:control container:container window:window environment:environment token:token ocr:NO]; return;
        }
        [self waitFor:control container:container token:token]; return;
    }
    [self recognize:container window:window environment:environment token:token];
}

- (NSDictionary *)recordFor:(UIControl *)control container:(UIView *)container {
    NSArray *path = ASGPath(control, container);
    CGRect r = ASGNormalizedRect(control, container);
    NSString *identifier = control.accessibilityIdentifier ?: @"";
    if (!path || identifier.length > 160 || !ASGRectValid(r.origin.x, r.origin.y, r.size.width, r.size.height)) return nil;
    return @{@"contextClass": NSStringFromClass(container.class), @"controlClass": NSStringFromClass(control.class),
             @"identifier": identifier, @"semantic": @"skip", @"path": path,
             @"rect": @[@(r.origin.x), @(r.origin.y), @(r.size.width), @(r.size.height)]};
}

- (void)tap:(UIControl *)control container:(UIView *)container window:(UIWindow *)window
  environment:(NSString *)environment token:(uint64_t)token ocr:(BOOL)ocr {
    if (_attempted || !ASGSessionValid(&_session, token, ASGNow()) || ASGWindow() != window
        || [self context:window] != container || ![self validControl:control container:container window:window requireText:!ocr]) return;
    UIViewController *top = ASGTopController(window.rootViewController);
    UIViewController *expected = (top.isViewLoaded && top.view == container && top.presentingViewController)
        ? top.presentingViewController : top;
    NSDictionary *record = ocr ? nil : [self recordFor:control container:container];
    if (!expected || ASGExcludedPage(expected)) return;
    _attempted = YES;
    _session.verifying = YES;
    _session.deadline = MAX(_session.deadline, ASGNow() + 1.5);
    // Public action only; never enable a disabled button or synthesize a touch.
    if (!(control.allControlEvents & UIControlEventTouchUpInside)) { [self cancel]; return; }
    [control sendActionsForControlEvents:UIControlEventTouchUpInside];
    __weak UIView *oldContainer = container;
    __weak UIWindow *oldWindow = window;
    __weak UIViewController *expectedController = expected;
    for (NSNumber *delay in @[@0.35, @0.9]) {
        [self schedule:delay.doubleValue token:token block:^(ASGGuard *guard) {
            UIWindow *current = ASGWindow();
            UIViewController *vc = ASGTopController(current.rootViewController);
            UIView *prior = oldContainer;
            BOOL detached = !prior || !prior.window || prior.hidden;
            BOOL verified = current && current == oldWindow && vc && vc == expectedController
                && !ASGExcludedPage(vc) && detached && ![guard context:current];
            if (verified) {
                if (record) [guard->_cache confirmRecord:record environment:environment];
                [guard cancel];
            } else if (delay.doubleValue > 0.8) {
                [guard->_cache invalidateEnvironment:environment];
                [guard cancel];
            }
        }];
    }
}

- (void)recognize:(UIView *)container window:(UIWindow *)window environment:(NSString *)environment token:(uint64_t)token {
    NSProcessInfo *process = NSProcessInfo.processInfo;
    if (_ocrStarted || _ocrInFlight || _ocrDisabledForLaunch || process.lowPowerModeEnabled
        || process.thermalState >= NSProcessInfoThermalStateSerious) return;
    _ocrStarted = YES;
    _ocrInFlight = YES; // Set before dispatch, not after completion.
    __weak ASGGuard *owner = self;
    __weak UIView *weakContainer = container;
    __weak UIWindow *weakWindow = window;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool {
            static void *vision;
            static dispatch_once_t once;
            dispatch_once(&once, ^{ vision = dlopen("/System/Library/Frameworks/Vision.framework/Vision", RTLD_LAZY | RTLD_LOCAL); });
            Class requestClass = vision ? NSClassFromString(@"VNRecognizeTextRequest") : Nil;
            Class handlerClass = vision ? NSClassFromString(@"VNImageRequestHandler") : Nil;
            dispatch_async(dispatch_get_main_queue(), ^{
                ASGGuard *guard = owner;
                if (!guard) return;
                UIView *context = weakContainer;
                UIWindow *activeWindow = weakWindow;
                if (!context || !activeWindow || !requestClass || !handlerClass || !ASGSessionValid(&guard->_session, token, ASGNow())
                    || guard->_session.verifying || ASGWindow() != activeWindow || [guard context:activeWindow] != context) {
                    guard->_ocrInFlight = NO; return;
                }
                // Crop during rendering, not after making a full-screen screenshot.
                CGRect bounds = context.bounds;
                CGRect roi = CGRectMake(bounds.origin.x + bounds.size.width * 0.55, bounds.origin.y,
                                        bounds.size.width * 0.45, bounds.size.height * 0.25);
                BOOL rendered;
                UIImage *image = ASGRenderROI(context, roi, &rendered);
                double capturedAt = ASGNow();
                if (!rendered) {
                    guard->_ocrDisabledForLaunch = YES; guard->_ocrInFlight = NO; return;
                }
                id request = [requestClass new];
                [request setValue:@0 forKey:@"recognitionLevel"];
                [request setValue:@NO forKey:@"usesLanguageCorrection"];
                [request setValue:@YES forKey:@"preferBackgroundProcessing"];
                guard->_ocrRequest = request;
                CGRect contextFrame = [context convertRect:context.bounds toView:activeWindow];
                dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                    @autoreleasepool {
                        NSData *imageDigest = ASGImageDigest(image);
                        NSError *languageError = nil;
                        NSArray *languages = ((id (*)(id, SEL, NSError **))objc_msgSend)(request, NSSelectorFromString(@"supportedRecognitionLanguagesAndReturnError:"), &languageError);
                        NSMutableArray *chosen = [NSMutableArray array];
                        for (NSString *desired in @[@"zh-Hans", @"en-US"]) if ([languages containsObject:desired]) [chosen addObject:desired];
                        if (chosen.count) [request setValue:chosen forKey:@"recognitionLanguages"];
                        id handler = ((id (*)(id, SEL, CGImageRef, NSDictionary *))objc_msgSend)([handlerClass alloc], NSSelectorFromString(@"initWithCGImage:options:"), image.CGImage, @{});
                        NSError *error = nil;
                        BOOL ok = ((BOOL (*)(id, SEL, NSArray *, NSError **))objc_msgSend)(handler, NSSelectorFromString(@"performRequests:error:"), @[request], &error);
                        CGRect match = CGRectNull;
                        unsigned matches = 0;
                        if (ok && !error) {
                            for (id observation in [request valueForKey:@"results"]) {
                                NSArray *candidates = ((id (*)(id, SEL, NSUInteger))objc_msgSend)(observation, NSSelectorFromString(@"topCandidates:"), 1);
                                id candidate = candidates.firstObject;
                                if (!candidate || !ASGSkipText([candidate valueForKey:@"string"]) || [[candidate valueForKey:@"confidence"] floatValue] < 0.95) continue;
                                CGRect box = [[observation valueForKey:@"boundingBox"] CGRectValue];
                                if (!ASGRectValid(box.origin.x, box.origin.y, box.size.width, box.size.height)) continue;
                                match = CGRectMake(roi.origin.x + box.origin.x * roi.size.width,
                                                   roi.origin.y + (1 - box.origin.y - box.size.height) * roi.size.height,
                                                   box.size.width * roi.size.width, box.size.height * roi.size.height);
                                matches++;
                            }
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            ASGGuard *current = owner;
                            if (!current) return;
                            current->_ocrInFlight = NO;
                            if (current->_ocrRequest == request) current->_ocrRequest = nil;
                            UIView *containerNow = weakContainer;
                            UIWindow *windowNow = weakWindow;
                            if (!containerNow || !windowNow || matches != 1 || !ASGSessionValid(&current->_session, token, ASGNow()) || current->_session.verifying
                                || ASGWindow() != windowNow || [current context:windowNow] != containerNow
                                || ASGNow() - capturedAt > 0.75
                                || !CGRectEqualToRect(contextFrame, [containerNow convertRect:containerNow.bounds toView:windowNow])) return;
                            // Cached geometry alone does not prove that the old OCR image is still current.
                            BOOL fresh;
                            UIImage *currentImage = ASGRenderROI(containerNow, roi, &fresh);
                            if (!fresh || !imageDigest || ![imageDigest isEqual:ASGImageDigest(currentImage)]) return;
                            CGPoint point = [containerNow convertPoint:CGPointMake(CGRectGetMidX(match), CGRectGetMidY(match)) toView:windowNow];
                            UIControl *control = ASGControlFromView([windowNow hitTest:point withEvent:nil], containerNow);
                            // OCR does not license a blind coordinate tap or an uncertain persistent cache.
                            if ([current validControl:control container:containerNow window:windowNow requireText:NO]) {
                                [current tap:control container:containerNow window:windowNow environment:environment token:token ocr:YES];
                            }
                        });
                    }
                });
            });
        }
    });
}
@end

static void (*ASGOriginalSendEvent)(id, SEL, UIEvent *);
static void ASGSendEvent(id app, SEL selector, UIEvent *event) {
    if (ASGArmed && event.type == UIEventTypeTouches) {
        for (UITouch *touch in event.allTouches) if (touch.phase == UITouchPhaseBegan) { [[ASGGuard shared] userTouched]; break; }
    }
    ASGOriginalSendEvent(app, selector, event);
}

static BOOL ASGHostAllowed(void) {
    NSBundle *bundle = NSBundle.mainBundle;
    NSString *identifier = bundle.bundleIdentifier.lowercaseString;
    if (ASGDeniedBundle(identifier.UTF8String)) return NO;
    NSString *name = [NSString stringWithFormat:@"%@ %@ %@", bundle.infoDictionary[@"CFBundleDisplayName"] ?: @"",
                      bundle.infoDictionary[@"CFBundleName"] ?: @"", bundle.infoDictionary[@"LSApplicationCategoryType"] ?: @""];
    for (NSString *term in @[@"银行", @"证券", @"支付", @"金融", @"京东", @"淘宝", @"闲鱼", @"蚂蚁", @"支付宝", @"bank", @"finance", @"broker", @"wallet"]) {
        if (ASGHasWord(name, term)) return NO;
    }
    return YES;
}

__attribute__((constructor)) static void ASGBootstrap(void) {
    // Required app-local dylib entry point: no OCR, disk I/O, or eager touch objects here.
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!ASGHostAllowed()) return;
        ASGGuard *guard = [ASGGuard shared];
        Method method = class_getInstanceMethod(UIApplication.class, @selector(sendEvent:));
        if (method) ASGOriginalSendEvent = (void (*)(id, SEL, UIEvent *))method_setImplementation(method, (IMP)ASGSendEvent);
        [guard activate];
    });
}
