#ifndef ASG_POLICY_H
#define ASG_POLICY_H
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint64_t generation;
    double deadline;
    unsigned probes;
    bool active;
    bool verifying;
} ASGSession;

bool ASGDeniedBundle(const char *bundle);
bool ASGSessionValid(const ASGSession *session, uint64_t token, double now);
bool ASGConsumeProbe(ASGSession *session, double now);
bool ASGRectValid(double x, double y, double width, double height);
bool ASGCornerButton(double x, double y, double width, double height);
bool ASGMayPromote(unsigned confirmations, bool verified, bool uncertain);
void ASGCancelSession(ASGSession *session);
#endif
