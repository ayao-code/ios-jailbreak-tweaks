#import "ASGMatchers.h"

BOOL ASGSkipText(NSString *text) {
    if (![text isKindOfClass:NSString.class] || text.length > 20) return NO;
    NSString *value = [[text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet] lowercaseString];
    static NSRegularExpression *pattern;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pattern = [NSRegularExpression regularExpressionWithPattern:@"^(跳过|skip)([\\s()（）]*[0-9]{1,2}[\\s]*(s|秒)?[\\s()（）]*)?$" options:0 error:NULL];
    });
    return value.length && [pattern numberOfMatchesInString:value options:0 range:NSMakeRange(0, value.length)] == 1;
}

BOOL ASGSkipIdentifier(NSString *identifier) {
    if (![identifier isKindOfClass:NSString.class] || identifier.length > 160) return NO;
    static NSRegularExpression *pattern;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        pattern = [NSRegularExpression regularExpressionWithPattern:@"(^|[^a-z])skip([^a-z]|$)|skipbutton|skipad|adskip" options:NSRegularExpressionCaseInsensitive error:NULL];
    });
    return [pattern numberOfMatchesInString:identifier options:0 range:NSMakeRange(0, identifier.length)] > 0;
}

BOOL ASGAdClass(NSString *name) {
    NSString *lower = name.lowercaseString;
    if (!lower.length) return NO;
    // Do not match the incidental "ad" in names such as LoadingSplashView.
    for (NSString *word in @[@"splashad", @"adsplash", @"splashadvert", @"launchad", @"appopenad"]) {
        if ([lower containsString:word]) return YES;
    }
    return NO;
}
