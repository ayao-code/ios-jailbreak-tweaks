#include "ASGPolicy.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

int main(void) {
    const char *denied[] = {NULL, "", "com.apple.springboard", "com.taobao.fleamarket",
        "com.eg.android.AlipayGphone", "com.360buy.jdmobile", "com.citicbank.creditspace",
        "com.icbc.iphoneclient", "com.paypal.app", "example.wallet.app", "com.xueqiu"};
    for (unsigned i = 0; i < sizeof(denied) / sizeof(*denied); i++) assert(ASGDeniedBundle(denied[i]));
    assert(!ASGDeniedBundle("com.tencent.xin"));
    assert(!ASGDeniedBundle("com.qunar.iphoneclient8"));
    ASGSession session = {.generation = 4, .deadline = 4, .active = true};
    assert(ASGSessionValid(&session, 4, 0));
    assert(!ASGSessionValid(&session, 3, 0));
    assert(!ASGSessionValid(&session, 4, 4));
    assert(!ASGSessionValid(&session, 4, NAN));
    for (unsigned i = 0; i < 6; i++) assert(ASGConsumeProbe(&session, 1));
    assert(!ASGConsumeProbe(&session, 1));
    ASGCancelSession(&session);
    assert(!ASGSessionValid(&session, 4, 1));
    assert(session.generation == 5 && !session.active);
    assert(ASGCornerButton(.75, .05, .15, .05));
    assert(ASGCornerButton(.05, .05, .15, .05));
    assert(!ASGCornerButton(.45, .05, .15, .05));
    assert(!ASGCornerButton(.75, .75, .15, .05));
    assert(!ASGRectValid(NAN, 0, .1, .1));
    assert(!ASGRectValid(-.1, 0, .1, .1));
    assert(!ASGRectValid(0, 0, 0, .1));
    assert(!ASGRectValid(.9, 0, .2, .1));
    assert(!ASGMayPromote(1, true, false));
    assert(!ASGMayPromote(2, false, false));
    assert(!ASGMayPromote(2, true, true));
    assert(ASGMayPromote(2, true, false));
    puts("PASS policy: deny boundaries, generation cancellation, deadline, budgets, rectangles, uncertain promotion");
    return 0;
}
