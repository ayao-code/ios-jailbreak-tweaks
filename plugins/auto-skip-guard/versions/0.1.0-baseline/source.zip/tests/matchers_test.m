#import <Foundation/Foundation.h>
#import "ASGMatchers.h"
#include <assert.h>

int main(void) {
    @autoreleasepool {
        for (NSString *s in @[@"跳过", @" Skip ", @"跳过 3s", @"跳过(5秒)", @"SKIP 2"]) assert(ASGSkipText(s));
        for (NSString *s in @[@"关闭", @">>", @"点击跳过登录", @"跳过教程", @"skip login", @"", @"跳过 100秒"]) assert(!ASGSkipText(s));
        assert(!ASGSkipText(nil));
        assert(ASGSkipIdentifier(@"sdk_skip_button"));
        assert(!ASGSkipIdentifier(@"skipper_profile"));
        assert(ASGAdClass(@"BUSplashAdView"));
        assert(ASGAdClass(@"GADAppOpenAdController"));
        assert(!ASGAdClass(@"LoadingSplashView"));
        assert(!ASGAdClass(@"LoginViewController"));
        assert(!ASGAdClass(nil));
        puts("PASS matchers: anchored skip text, broad-close rejection, identifier boundaries, loading-screen false positives");
    }
    return 0;
}
