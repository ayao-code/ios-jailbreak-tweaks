#import <Foundation/Foundation.h>
BOOL ASGSkipText(NSString *text);
BOOL ASGSkipIdentifier(NSString *identifier);
BOOL ASGAdClass(NSString *name);
