#include "ASGPolicy.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

bool ASGDeniedBundle(const char *bundle) {
    if (!bundle || !*bundle) return true;
    static const char *prefixes[] = {
        "com.apple.", "com.taobao.", "com.alibaba.", "com.alipay.",
        "com.eg.android.AlipayGphone", "com.alimama.", "com.autonavi.",
        "com.ucweb.", "com.youku.", "com.cainiao.", "cn.damai.",
        "me.ele.", "com.360buy.", "com.jd.", "com.jdcar.",
        "com.jingdong.", "com.boc.", "com.ccb.", "com.icbc.",
        "com.cmb.", "com.cmbchina.", "com.bank.", "com.bankcomm.",
        "com.citicbank.", "com.cebbank.", "com.pingan.", "com.ppdai.",
        "com.xueqiu", "com.paypal.", "com.unionpay.", "com.chinaums.",
        "com.tencent.tenpay", "com.eastmoney.", "cn.com.gjzq.",
        "com.hexin.", "com.htsec.", "com.hundsun.", "com.webull.",
        "com.robinhood.", "com.revolut.", "com.chase.", "com.hsbc.",
    };
    for (size_t i = 0; i < sizeof(prefixes) / sizeof(*prefixes); i++) {
        if (!strncmp(bundle, prefixes[i], strlen(prefixes[i]))) return true;
    }
    // Fail closed on obvious financial identifiers; not an exhaustive registry.
    static const char *tokens[] = {"bank", "alipay", "securit", "broker", "finance", "wallet", "payment"};
    for (size_t i = 0; i < sizeof(tokens) / sizeof(*tokens); i++) {
        if (strstr(bundle, tokens[i])) return true;
    }
    return false;
}

bool ASGSessionValid(const ASGSession *s, uint64_t token, double now) {
    return s && s->active && s->generation == token && isfinite(now) && now < s->deadline;
}

bool ASGConsumeProbe(ASGSession *s, double now) {
    if (!s || !ASGSessionValid(s, s->generation, now) || s->verifying || s->probes >= 6) return false;
    s->probes++;
    return true;
}

bool ASGRectValid(double x, double y, double w, double h) {
    return isfinite(x) && isfinite(y) && isfinite(w) && isfinite(h)
        && x >= 0 && y >= 0 && w > 0 && h > 0 && x + w <= 1.001 && y + h <= 1.001;
}

bool ASGCornerButton(double x, double y, double w, double h) {
    if (!ASGRectValid(x, y, w, h)) return false;
    return w <= 0.40 && h <= 0.16 && y + h <= 0.30 && (x + w <= 0.40 || x >= 0.60);
}

bool ASGMayPromote(unsigned confirmations, bool verified, bool uncertain) {
    return confirmations >= 2 && verified && !uncertain;
}

void ASGCancelSession(ASGSession *s) {
    if (!s) return;
    s->active = false;
    s->verifying = false;
    s->generation++;
}
