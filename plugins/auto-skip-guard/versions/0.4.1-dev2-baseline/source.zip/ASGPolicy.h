#ifndef ASG_POLICY_H
#define ASG_POLICY_H
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint64_t generation;
    double deadline;
    unsigned probes;
    bool active;
    bool verifying;
} ASGSession;

bool ASGSessionValid(const ASGSession *session, uint64_t token, double now);
bool ASGConsumeProbe(ASGSession *session, double now);
bool ASGRectValid(double x, double y, double width, double height);
bool ASGCornerButton(double x, double y, double width, double height);
bool ASGAdCloseButton(double x, double y, double width, double height);
bool ASGSuccessFeedback(bool dispatched, bool samePage, bool targetGone, bool containerGone, bool active, bool sceneStable);
bool ASGMayPromote(unsigned confirmations, bool verified, bool uncertain);
bool ASGOCRResultValid(uint64_t currentToken, uint64_t resultToken, double age, bool samePage);
bool ASGOCRPairAgrees(double overlap, bool sameMeaning, bool samePage);
bool ASGShouldAttemptSkip(bool visible, bool unique, bool skipSemantic, bool userInteraction, bool countdown, bool enabled);
bool ASGAuthorizeCandidate(bool skip, bool explicitAd, bool countdown, bool overlay, bool arrow,
                          double x, double y, double width, double height);
bool ASGExitEvidenceSafe(int seconds, double elapsed);
bool ASGObserveExit(double *firstSeen, double now, bool evidence);
void ASGCancelSession(ASGSession *session);
#endif
